package com.quellxcode.myapp

import android.databinding.BaseObservable

class Custom(val name: String?) : BaseObservable()
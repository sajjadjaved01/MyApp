package com.quellxcode.myapp

import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import com.quellxcode.myapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    val items: ArrayList<Custom> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
        val bind = DataBindingUtil.setContentView<ActivityMainBinding>(this, R.layout.activity_main)

        items.add(Custom("Sajjad"))
        items.add(Custom("Hassan"))
        items.add(Custom("Faizan"))
        items.add(Custom("Zain"))

        bind.recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        bind.recycler.itemAnimator = DefaultItemAnimator()
        bind.recycler.adapter = CustomAdapter(items)

        val cus = Custom("Sajjad")
        bind.data = cus

    }
}
